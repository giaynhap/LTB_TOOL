#ifndef GNVECTORLIB
#define GNVECTORLIB
#include "gnMatrix.h"
#include <math.h>
typedef char byte;
class gnVector
{

public:
	double *data;
	byte size;
	gnVector(int size);
	gnVector();
	~gnVector();
	bool operator=(gnVector a);
	bool operator==(gnVector a);
	bool operator!=(gnVector a);
	gnVector operator+(gnVector vec) const;
	gnVector operator-(gnVector vec) const;
	gnVector operator*(double a) const;
	gnVector operator/(double a) const;
	double Length();
	
	double Normalize();

	double operator*(gnVector vec) const;

	bool operator+=(gnVector vec) const;
	bool operator-=(gnVector vec) const;
	bool  operator*=(double a) const;
	bool  operator/=(double a) const;
	gnMatrix toMatrix()
	{
		gnMatrix rMatrix(size,1);
		for (int i=0 ;i< size;i++)
			rMatrix.data[i][0]= data[i];

		return rMatrix;
	};

	template <size_t size_x>
	void parse(double (&arr)[size_x]);
	
	void clean()
	{
		size =0;
		delete []data;
	}
};

#endif