#include "gnVector.h"
#include "gnMatrix.h"

#include <iostream>
#include <stdio.h>

#define DEBUG
#if defined(DEBUG)

int main()
{
		gnMatrix Matrix  ;

		gnMatrix Matrix2(0,0);
		double a[3][3] ={{0,2,-3},{0,1,3},{2,0,-1}} ;
		double b[4][4] ={{9,1,2,1},{0,-1,0,0},{0,5,4,2},{3,1,4,1}} ;
		Matrix.parse(a);
		//Matrix=Matrix.Inverse(); 
		//Matrix=Matrix^-1; 
		//Matrix = Matrix^3; 
		//Matrix+=Matrix; 

		Matrix2.parse(a);
		
		//Matrix2 =  Matrix*Vector.toMatrix();
			//Matrix = Matrix^3;		
		//printf ("\n%f %f %f\n%f %f %f\n%f %f %f\n",Matrix2.data[0][0],Matrix2.data[0][1],Matrix2.data[0][2],Matrix2.data[1][0],Matrix2.data[1][1],Matrix2.data[1][2],Matrix2.data[2][0],Matrix2.data[2][1],Matrix2.data[2][2]);
		
		///printf ("Dinh thuc Matrix2 :  %f \n",Matrix2.det());
		
		std::system("pause");
	return 0;
}
#endif