#include "gnVector.h"


gnVector::gnVector(int size)
{
  data = new double (size);
}

bool gnVector::operator=(gnVector vec)
{
	data = new double [vec.size];
	for (int i=0;i<vec.size;i++ )
	    data[i]= vec.data[i];
	return true;
}
bool gnVector::operator==(gnVector a)
{
	for (int i=0;i<size;i++)
		if (data[i]!=a.data[i]) return false;
	return true;
}
bool gnVector::operator!=(gnVector a)
{
	return  !(*this==a);
}
gnVector gnVector::operator+(gnVector vec) const
{
	gnVector rVector (vec.size);
	if (vec.size != size) return rVector;
	for (int i=0;i<size;i++)
		rVector.data[i]=data[i]+vec.data[i];
	return rVector;
}

gnVector gnVector::operator-(gnVector vec) const
{
	gnVector rVector (vec.size);
	if (vec.size != size) return rVector;
	for (int i=0;i<size;i++)
		rVector.data[i]=data[i]-vec.data[i];
	return rVector;
}

double gnVector::operator*(gnVector vec) const
{
	double resual=0.0f;
	if (vec.size != size) return 0.0f;
	for (int i=0;i<size;i++)
		resual += data[i]*vec.data[i];
	return resual;
}

bool gnVector::operator+=(gnVector vec) const
{
	if (vec.size != size) return false;
	for (int i=0;i<size;i++)
		data[i]+=vec.data[i];
	return true;		
}

bool gnVector::operator-=(gnVector vec) const
{
	gnVector rVector (vec.size);
	if (vec.size != size) return false;
	for (int i=0;i<size;i++)
		data[i]-=vec.data[i];
	return true;	
}
bool  gnVector::operator*=(double a) const
{
	for (int i=0;i<size;i++)
		data[i]*=a;
	return true;
}
bool  gnVector::operator/=(double a) const
{

	for (int i=0;i<size;i++)
		data[i]/=a;
	return true;
}

gnVector  gnVector::operator*(double a) const
{
	gnVector rVector (size);
	for (int i=0;i<size;i++)
	rVector.data[i]=data[i]*a;
	return rVector;
}
gnVector  gnVector::operator/(double a) const
{
	gnVector rVector (size);
	for (int i=0;i<size;i++)
	rVector.data[i]=data[i]/a;
	return rVector;
}

double gnVector::Length()
{
	 double resual=0.0f;
	 for (int i=0;i<size;i++)
		 resual+=data[i]*data[i];
	 return sqrt(resual);
}


double gnVector::Normalize()
{
	double S = this->Length() ;
	if(S > 0.0f)
	{
		for (int i=0;i<size;i++)
			data[i]*= 1.0f/sqrtf(S);
		return S*  1.0f/sqrtf(S);
	}
	return 0.0f;
}
template <size_t size_x>
void gnVector::parse(double (&arr)[size_x])
{
	size = size_x;
	data = new double[size_x];
	for (int i=0 ;i< size_x;i++)
		data[i]=arr[i];
}
gnVector::gnVector()
{
	size =0;
	data = new double[0];
}
gnVector::~gnVector()
{
	size =0;
	data = new double[0];
}
