#ifndef GNMATRIXLIB
#define GNMATRIXLIB
#include <math.h>
#include <stdio.h>
typedef struct i_v2d
{
	int x;
	int y;
} i_v2d_t;
 class gnMatrix
{
public :
		
	gnMatrix(int x,int y);
	gnMatrix();
	~gnMatrix();
	double	**data;

	gnMatrix operator^(int a) ;

	gnMatrix operator/(double a) const;


	gnMatrix operator*(double a) const;


	bool operator*=(double a) const;
	bool operator/=(double a) const;

	
	gnMatrix operator+(gnMatrix a) const;
	gnMatrix operator-(gnMatrix a) const;

	bool operator+=(gnMatrix a);
	bool operator-=(gnMatrix a);

	gnMatrix operator*(gnMatrix a) const;
	bool operator*=(gnMatrix a) ;
	gnMatrix& operator=(gnMatrix& m);
	double det();
	gnMatrix Inverse();
	 
	void clean_data()
	{
		delete[]data;
		size.x=0;
		size.y=0;
	};

	template <size_t size_x, size_t size_y>
	void parse(double (&arr)[size_x][size_y]);
	

private:
	gnMatrix __getM(int x, int y);
	 i_v2d_t size;
};

 
#endif
